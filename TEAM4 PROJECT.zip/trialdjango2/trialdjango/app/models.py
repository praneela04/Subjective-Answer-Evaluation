from django.db import models

# Create your models here.
class tockens:
    tockens = models.CharField(verbose_name="Given Name", max_length=200, blank=False, null=False)