from django.shortcuts import render

from .forms import DocumentForm
from .driver import Driver

from .bluescore import cal_bleu_score
from .meteor import cal_meteor_score
from .jacard import jaccard_similarity
from .wmd import wmd_similarity



def analysis(request):
    if request.method== 'POST':
        form =DocumentForm(request.POST,request.FILES)
        if form.is_valid():
            document =request.FILES['document']
            question =form.cleaned_data.get('question','')
            answer=form.cleaned_data.get('answer','')
            result,score=Driver(document,question)
            print(result)
            finscore=final_score(result,answer)
            return render(request, 'app/results.html', {'result': result,'question':question,'answer':answer,'finalscore':finscore})
    else:
        form = DocumentForm()
    return render(request, 'app/index.html', {'form': form})
def final_score(result,answer):
    print(result)
    print(answer)
    result1=result.split()
    answer1=answer.split() 
    bluescore=cal_bleu_score(result,answer)
    wmd=wmd_similarity(result,answer)
    meteor=cal_meteor_score([result1],answer1)
    s1=set(result.lower().split())
    s2=set(answer.lower().split())
    print(s1)
    print(s2)
    jacard=jaccard_similarity(s1,s2)
    print("check")
    print(answer)
    print(result)
    print(f"bluescore: {bluescore}")
    print(f"wmd: {wmd}")
    print(f"meteor:{meteor}")
    print(f"jacard:{jacard}")
    return (0.2*bluescore)+(0.2*jacard)+(0.3*meteor)+(0.3*wmd)