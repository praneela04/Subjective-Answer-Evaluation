from transformers import DistilBertForQuestionAnswering, DistilBertTokenizer
import torch
import re
from .documentProcessing import DocumentProcessing
from .relevantParagraph import RelevantParagraph
def remove_hashtags(input_string):
    words = input_string.split()
    result = []

    for word in words:
        if '#' in word:
            word = word.replace('#', '')
            if result:
                result[-1] += word
            else:
                result.append(word)
        else:
            result.append(word)

    return ' '.join(result)

def Driver(document,user_query):
  DocProcessing=DocumentProcessing(document)
  paragraphs, paragraph_embeddings, faiss_index = DocProcessing.covert_word_to_array()
  RelevantTextExtract = RelevantParagraph(user_query, faiss_index, paragraphs)
  relevant_paragraph = RelevantTextExtract.Return()
  print(relevant_paragraph)
  print("")
  relstring=' '.join(relevant_paragraph)
  model_name = "distilbert-base-uncased-distilled-squad"  # Pre-trained model for question answering
  tokenizer = DistilBertTokenizer.from_pretrained(model_name)
  model = DistilBertForQuestionAnswering.from_pretrained(model_name)

  encoding = tokenizer(user_query, str(relevant_paragraph),  return_tensors="pt", truncation=True, padding=True)
  outputs = model(**encoding)
  start_scores, end_scores = outputs.start_logits, outputs.end_logits
  print(start_scores,end_scores)


  # Find the most likely answer span
  answer_start = torch.argmax(start_scores)
  answer_end = torch.argmax(end_scores) + 1  # +1 to account for inclusive end
  print(answer_start,answer_end)

  confidence_score = calculate_confidence_score(start_scores, end_scores)
  print(f"Confidence Score: {confidence_score:.4f}")
  if(confidence_score>0.7):
    try:
  # Attempt using convert_tokens_to_strings (newer version)
      answer = tokenizer.convert_tokens_to_strings(encoding.input_ids[0][answer_start:answer_end])
    except AttributeError:
  # Fallback to convert_ids_to_tokens (older version)
      answer_tokens = tokenizer.convert_ids_to_tokens(encoding.input_ids[0][answer_start:answer_end])
      #print(answer_tokens)
    answer = ' '.join(answer_tokens)  # Join tokens and remove whitespace around special tokens
    answer = remove_hashtags(answer)
  else:
    answer='Could not find relevant information in the document!!'

  print(f"Question: {user_query}")

  print(f"Answer: {answer}")
  return relstring,confidence_score
def calculate_confidence_score(start_logits, end_logits):
    # Use softmax to convert logits to probabilities
    start_probs = torch.nn.functional.softmax(start_logits, dim=-1)
    end_probs = torch.nn.functional.softmax(end_logits, dim=-1)

    # Calculate maximum probability
    max_prob = torch.max(torch.cat([start_probs, end_probs], dim=-1))
    return max_prob.item()

# ... rest of your code