import faiss
def create_faiss_index(embeddings):
  """
  Function to create a FAISS index for efficient similarity search.
  """
  index = faiss.IndexFlatL2(embeddings.shape[1])  # L2 distance for cosine similarity
  index.add(embeddings)
  return index
