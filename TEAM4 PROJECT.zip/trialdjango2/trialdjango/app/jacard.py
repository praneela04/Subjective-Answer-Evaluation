import numpy as np
from gensim.models import Word2Vec
from gensim.similarities import WmdSimilarity
#from gensim.matutils import softcossim
from gensim.similarities.docsim import SoftCosineSimilarity
from gensim import corpora
from sentence_transformers import SentenceTransformer
from nltk.translate.bleu_score import corpus_bleu
from nltk.translate.meteor_score import meteor_score
#import textgears_api_client
from sklearn.decomposition import PCA

def jaccard_similarity(set1, set2):
    """Calculates the Jaccard similarity between two sets.

    Args:
        set1 (set): The first set.
        set2 (set): The second set.

    Returns:
        float: The Jaccard similarity score between the two sets.
    """

    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union