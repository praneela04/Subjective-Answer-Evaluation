import numpy as np
from gensim.models import Word2Vec
from gensim.similarities import WmdSimilarity
#from gensim.matutils import softcossim
from gensim.similarities.docsim import SoftCosineSimilarity
from gensim import corpora
from sentence_transformers import SentenceTransformer
from nltk.translate.bleu_score import corpus_bleu

#import textgears_api_client
from sklearn.decomposition import PCA

from nltk.translate.meteor_score import meteor_score
import nltk
nltk.download('wordnet')
def cal_meteor_score(candidate, reference):
    

    return meteor_score(candidate, reference)
