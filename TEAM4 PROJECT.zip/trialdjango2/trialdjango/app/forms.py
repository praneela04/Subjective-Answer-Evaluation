
from django import forms

class DocumentForm(forms.Form):
    document = forms.FileField()
    question = forms.CharField(max_length=255, required=True) 
    answer = forms.CharField(widget=forms.Textarea(attrs={'maxlength': 500}), required=True)