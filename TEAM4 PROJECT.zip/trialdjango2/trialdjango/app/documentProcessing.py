import docx
from sentence_transformers import SentenceTransformer
from .faiss import create_faiss_index

class DocumentProcessing:
  def __init__(self, document):
    self.document = document

  def covert_word_to_array(self):
    """
    Function to process document, generate embeddings, and create FAISS index.
    """
    doc = docx.Document(self.document)
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    sbert_model = SentenceTransformer('sentence-transformers/multi-qa-distilbert-cos-v1')
    paragraph_embeddings = sbert_model.encode(paragraphs)
    faiss_index = create_faiss_index(paragraph_embeddings)
    return paragraphs, paragraph_embeddings, faiss_index