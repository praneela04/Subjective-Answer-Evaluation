import numpy as np
from gensim.models import Word2Vec
from gensim.similarities import WmdSimilarity
#from gensim.matutils import softcossim
from gensim.similarities.docsim import SoftCosineSimilarity
from gensim import corpora
from nltk.translate.bleu_score import corpus_bleu
from nltk.translate.meteor_score import meteor_score
#import textgears_api_client
from sklearn.decomposition import PCA
import gensim.downloader as api
from nltk.corpus import stopwords
from nltk import download
##download('stopwords')  # Download stopwords list.
import nltk
nltk.download('punkt')
stop_words = stopwords.words('english')
def encode_text(text):
    model_transformer = SentenceTransformer('bert-base-nli-mean-tokens')
    embeddings = model_transformer.encode(text)
    return embeddings

def preprocess(sentence):
    return [w for w in sentence.lower().split() if w not in stop_words]
model = api.load('word2vec-google-news-300')

from sentence_transformers import SentenceTransformer, util

def wmd_similarity(text1,text2):
  distance = model.wmdistance(preprocess(text1), preprocess(text2))
  embeddings1 = encode_text(text1)
  embeddings2 = encode_text(text2)
  if distance == 0:
        return 1.0  # Default similarity for identical texts

    # Find minimum and maximum WMD for normalization
  min_distance = min(distance, util.pytorch_cos_sim(embeddings1, embeddings2).item())  # Consider cosine similarity for very similar cases
  max_distance = max(distance, util.pytorch_cos_sim(embeddings1, embeddings2).item())

    # Normalize WMD for similarity score (0 for most similar, 1 for most dissimilar)
  similarity = 1 - (distance - min_distance) / (max_distance - min_distance)
  return similarity