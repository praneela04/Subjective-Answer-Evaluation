def encode_text(text):
    """Encodes a text into a vector embedding using SentenceTransformer.

    Args:
        text (str): The text to encode.

    Returns:
        np.ndarray: The vector embedding of the text.
    """

    model_transformer = SentenceTransformer('bert-base-nli-mean-tokens')
    embeddings = model_transformer.encode(text)
    return embeddings