from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
class RelevantParagraph:
  def __init__(self, query, faiss_index, paragraphs):
    self.query = query
    self.faiss_index = faiss_index
    self.paragraphs = paragraphs

    sbert_model = SentenceTransformer('sentence-transformers/multi-qa-distilbert-cos-v1')
    query_embedding = sbert_model.encode([query])

    # Find nearest neighbors
    distances, retrieved_ids = self.faiss_index.search(query_embedding, k=1)  # Retrieve top most similar
    self.relevant_paragraphs = [self.paragraphs[i] for i in retrieved_ids.ravel()]

  def Return(self):
    return self.relevant_paragraphs